#include <iostream>
#include <string>
#include <vector>


int main()
{
  std::string test_string;
  std::vector<std::string> vec;
  std::getline(std::cin, test_string);
  
  vec.push_back(test_string);

  vec.erase(0);



  puts("aa\n");
  puts("aa\n");
  puts("aa\n");
  puts("aa\n");
  puts("aa\n");
  puts("aa\n");
  puts("aa\n");
  return 0;

}